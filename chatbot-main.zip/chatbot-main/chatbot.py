greetingdict = ["hello", "hi","what's up", "hola", "how are you?", "greetings", "salutations", "hey", "sup", "wussup", "Hello", "Hi","What's up", "Hola", "How are you?", "Greetings", "Salutations", "Hey", "Sup", "Wussup"]

#welcome message
print("Don't be shy, say hi!")

#read user input
x = input("You said: ")
print(x)

#check if user input is a greeting
if x in greetingdict:
    print("Sara: Hi, pleased to meet you! My name is Sara.")
else:
    print(" It's rude not to greet new people!")
    